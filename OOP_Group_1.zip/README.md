# OOPBallers
## Project Overview
![alt text](https://github.com/SebastianKuhn/OOPBallers/blob/master/README/OOPBallers-Cropped.png)

# The Fucking Docs (read them)
## helper functions
### variable naming convention
name = function variable
username = database column name
### getDbCon()
For Julian the adress parser.read('../config/config.ini') works. 
For Sebi and Thomas the adress parser.read('/config/config.ini') works.





# Notes:
### type in bash shell
ssh oop@46.101.163.178
### to connect to server
mysql -u oop -pOop1234-
